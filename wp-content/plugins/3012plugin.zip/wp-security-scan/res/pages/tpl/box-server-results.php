<?php if(! WsdUtil::canLoad()) { return; } ?>
<?php echo WsdInfoServer::getServerInfo();?>

