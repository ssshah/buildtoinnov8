var redirectFunctions = require( "./redirects/functions" );

window.wpseo_undo_redirect = redirectFunctions.wpseo_undo_redirect;
window.wpseo_create_redirect = redirectFunctions.wpseo_create_redirect;
